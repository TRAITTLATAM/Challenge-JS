# Ejercicio

Completar el archivo main.js (ubicado en la raíz del proyecto) con el código. 

## 1
Cuando el sitio haya cargado, deberás mostrar un prompt() que solicite el nombre de usuario. Una vez completado, modificar el mensaje "Bienvenido Usuario" que aparece en la sección con id "banner" por "Bienvenido " seguido del nombre de usuario ingresado.

## 2
Dentro de la sección con id "intro" hay 2 etiquetas <section> con la clase "first" y "second", siendo una un elemento destacada y la otra no.
Deberás hacer que, al realizar click sobre alguna de ellas, se alternen de forma individual, es decir, si la apariencia del section era la de "Elemento Destacado" deberá tener la de "Elemento secundario", y viceversa, modificando el color del ícono y el texto que corresponda.

## 3
Cuando el usuario haga click en el botón dentro de la sección con id "main", se deberá agregar un nuevo div en el listado inferior, con la clase "list-element". Dentro del mismo se deberá respetar el orden existente, es decir, el siguiente deberá contener como título Item 3, el siguiente Item 4, y así consecutivamente.